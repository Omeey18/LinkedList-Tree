#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *next;
};

struct node* insertAtFirst(struct node *head,int data){
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    if(temp==NULL)
        printf("Overflow...!\n");
    
    temp->data = data;
    temp->next = head;
    return temp;
}
struct node* insertAtEnd(struct node *head,int data){
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    struct node *p =head;
    while(p->next!=NULL){
        p = p->next;
    }
    p->next = temp;
    temp->data = data;
    temp->next = NULL;
    
    return head;
}

struct node* insertAfterNode(struct node *head,struct node *prevNode,int data){
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    // node *p = prevNode;
    temp->next = prevNode->next;
    prevNode->next = temp;
    temp->data = data;
    
    return head;
}

struct node* insertAtIndex(struct node *head,int data,int index){
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    struct node *p = head;
    int i=0;
    if(index==1){
        head = insertAtFirst(head,data);
    }
    else{
        while(i!=index-2 && p!=NULL){
            p = p->next;
            i++;
        }
        if(p==NULL){
            printf("Wrong index\n");
        }else{
            temp->next = p->next;
            p->next = temp;
            temp->data = data;
        }
        
    }
    return head;
}

//delete first element of linked list 
struct node* deleteFirst(struct node *head){
    if(head==NULL){
        printf("Linked List is empty..!\n");
    }
    struct node *temp;
    temp = head->next;
    printf("Deleted element is %d\n",head->data);
    free(head);
    return temp;
}

//delete last element of linked list 
struct node* deleteLast(struct node *head){
    if(head==NULL){
        printf("Linked List is empty..!\n");
    }
    struct node *temp =head;
    struct node *prevNode;
    while(temp->next!=NULL){
        prevNode = temp;
        temp = temp->next;
    }
    printf("Deleted element is %d\n",temp->data);
    prevNode->next=NULL;
    free(temp);
    return head;
    
}

int countNode(struct node *head){
    
    int count=0;
    while(head!=NULL){
        head = head->next;
        count++;
    }
    return count;
}
void display(struct node *head){
    printf("[ ");
    while(head!=NULL){
        printf("%d ",head->data);
        head=head->next;
    }
    printf("]");
    printf("\n");
}
int main()
{
    struct node *head;
    head=(struct node*)malloc(sizeof(struct node));
    head =NULL;
    
    int data,in,index;
    
    while(in!=9)
    {
        printf("Enter 1 for Insert Data at first     |     Enter 2 for Insert data at Index\n");
        printf("Enter 3 for Insert Data at End       |     Enter 4 for Insert data after node\n");
        printf("Enter 5 delete First element         |     Enter 6 for delete Last element\n");
        printf("Enter 7 for Display Linked List      |     Enter 8 for count number of noeds\n");
        printf("                         Enter 9 for EXIT:   \n");
        scanf("%d",&in);
        
        printf("----------------------------------------------------------------\n");
    switch(in){
        case 1:
            printf("Enter Data: \n");
            scanf("%d",&data);
            head = insertAtFirst(head,data);
            break;
        case 2:
            printf("Enter Data & index: \n");
            scanf("%d %d",&data,&index);
            head = insertAtIndex(head,data,index);
            break;
        case 3:
            printf("Enter Data: \n");
            scanf("%d",&data);
            head = insertAtEnd(head,data);
            break;
        case 4:
            printf("Enter Data: \n");
            scanf("%d",&data);
            head = insertAfterNode(head,head,data);
            break;
        case 5:
            head = deleteFirst(head);
            break;
        case 6:
            head = deleteLast(head);
            break;
        case 7:
            display(head);
            break;
        case 8:
            printf("count = %d\n",countNode(head));
            break;
        case 9:
            printf("Fir milenge Bye...!\n");
            exit(1);
        default:
            printf("Invalid choice...!\n");
        
    }
    printf("----------------------------------------------------------------\n");
    }

    return 0;
}
